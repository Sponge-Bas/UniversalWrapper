import sys
import UniversalWrapper.universal_wrapper as UniversalWrapper
sys.modules[__name__] = UniversalWrapper
